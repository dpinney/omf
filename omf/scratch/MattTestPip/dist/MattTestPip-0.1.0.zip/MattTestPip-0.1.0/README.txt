====================
Matt is testing Pip!
====================

We want to package the OMF as a pip-installable Python module, so I am learning how to do this with a dummy module.  This module specifically contains naive implementations of finding the nth fibboncci and the nth prime.