''' Model type hidden to users. Usable for top secret missions. '''

def getStatus():
	return "finished"