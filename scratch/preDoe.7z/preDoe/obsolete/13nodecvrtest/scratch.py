#!/usr/bin/env python
# encoding: utf-8

import sys
import os
import CVRgrapher

CVRgrapher.main()